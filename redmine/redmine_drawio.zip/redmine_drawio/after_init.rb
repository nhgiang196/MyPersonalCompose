# encoding: utf-8
require_dependency 'redmine_drawio'
